# Tag

A tiny functionally declarative reactive web programming kernel

## Examples

View [examples/index.html](./examples/index.html) for documentation and real world examples.

## Contributing

For now, reach out to me at yooo@tychi.me and we'll figure something out.

## License

CC BY-SA 4.0
