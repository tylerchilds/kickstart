const initialTodoList = {
  filter: 'ALL',
  itemsContainerUrl: null,
  items: [],
  loading: true
}

export default initialTodoList
